Details about this assignment can be found [on the course webpage](http://cs231n.github.io/), under Assignment #1 of Spring 2017.



我从Q4开始才正式使用Jupiter,因此前面Q1~Q3的部分也许需要重新写一下.

